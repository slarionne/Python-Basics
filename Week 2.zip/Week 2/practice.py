# -*- coding: utf-8 -*-
"""
Created on Fri Feb  9 10:31:50 2018

@author: 595517
"""

claim = 'Branch: Army'

claim = claim.split()

print(claim[1])