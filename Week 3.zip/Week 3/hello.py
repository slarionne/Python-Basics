# - helloworld.py *- coding: utf-8 -*-
"""
This program simply prints the phrase "Hello, World!"

@author: wboyd
"""

print("Hello, World!")
print("Goodbye")
