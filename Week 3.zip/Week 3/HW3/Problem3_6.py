# -problem3_6.py *- coding: utf-8 -*-

import sys

""" Opens two files and copies one into the other line by line. """
infilename = sys.argv[1]
outfilename = sys.argv[2]

infile = open(infilename)
outfile = open(outfilename,'w')


for line in infile:
    line = len(line.strip("\n"))
    print(line)
#outfile.write
infile.close()
outfile.close()
